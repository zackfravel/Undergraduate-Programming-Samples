#!/bin/bash
set -u -e
javac GasTank.java
javac Engine.java
javac Car.java
javac DrivePanel.java
javac Assignment3.java

java Assignment3