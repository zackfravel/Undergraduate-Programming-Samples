#!/bin/bash
set -u -e
javac GasTank.java
javac Engine.java
javac Car.java

